### Logistic Regression

#define log reg model
log_model <- logistic_reg() %>%
  set_engine("glm") %>%
  set_mode("classification")

#create the workflow
log_wflow <- workflow() %>%
  add_model(log_model) %>%
  add_recipe(scf_recipe)

#fit model to training data
log_fit <- fit(log_wflow, train_data)

#training ROC AUC
log_train_aug <- augment(log_fit, new_data = train_data)
log_roc_auc_train <- log_train_aug %>%
  roc_auc(truth = occ_group, .pred_white_collar)

#training ROC plot
log_roc_plot_train <- log_train_aug %>%
  roc_curve(truth = occ_group, .pred_white_collar) %>%
  autoplot()

#save data
save(log_fit, log_train_aug, log_roc_auc_train, log_roc_plot_train,
     file = "logistic_regression_model.rda")


#------------------------------------------------------------------------------#

## Ridge
# Define ridge model (mixture = 0 for ridge)
ridge_model <- logistic_reg(penalty = tune(), mixture = 0) %>%
  set_engine("glmnet") %>%
  set_mode("classification")

# Create workflow
ridge_wflow <- workflow() %>%
  add_model(ridge_model) %>%
  add_recipe(scf_recipe)

# Define grid
ridge_grid <- grid_regular(
  penalty(range = c(0, 1), trans = identity_trans()),
  levels = 30
)

# Tune model using cross-validation
ridge_tune <- tune_grid(
  ridge_wflow,
  resamples = folds,
  grid = ridge_grid,
  metrics = metric_set(roc_auc)
)

ridge_tune_plot <- autoplot(ridge_tune)

best_ridge <- ridge_tune %>%
  select_by_one_std_err(metric = "roc_auc", penalty)

final_ridge <- finalize_workflow(ridge_wflow, best_ridge)
ridge_fit <- fit(final_ridge, train_data)

ridge_aug <- augment(ridge_fit, new_data = train_data)

ridge_roc_auc_train <- ridge_aug %>%
  roc_auc(truth = occ_group, .pred_white_collar)

ridge_roc_plot_train <- ridge_aug %>%
  roc_curve(truth = occ_group, .pred_white_collar) %>%
  autoplot()

save(ridge_tune, ridge_tune_plot, best_ridge, ridge_fit,
     ridge_aug, ridge_roc_auc_train, ridge_roc_plot_train,
     file = "ridge_model_results.rda")

#----------------------------------------------------------------------------#


## Lasso


# Define lasso model (mixture = 1 for lasso)
lasso_model <- logistic_reg(penalty = tune(), mixture = 1) %>%
  set_engine("glmnet") %>%
  set_mode("classification")

# Create workflow
lasso_wflow <- workflow() %>%
  add_model(lasso_model) %>%
  add_recipe(scf_recipe)

# Define grid
lasso_grid <- grid_regular(
  penalty(range = c(0, 1), trans = identity_trans()),
  levels = 30
)

# Tune model
lasso_tune <- tune_grid(
  lasso_wflow,
  resamples = folds,
  grid = lasso_grid,
  metrics = metric_set(roc_auc)
)

lasso_tune_plot <- autoplot(lasso_tune)

best_lasso <- lasso_tune %>%
  select_by_one_std_err(metric = "roc_auc", penalty)

final_lasso <- finalize_workflow(lasso_wflow, best_lasso)
lasso_fit <- fit(final_lasso, train_data)

lasso_aug <- augment(lasso_fit, new_data = train_data)

lasso_roc_auc_train <- lasso_aug %>%
  roc_auc(truth = occ_group, .pred_white_collar)

lasso_roc_plot_train <- lasso_aug %>%
  roc_curve(truth = occ_group, .pred_white_collar) %>%
  autoplot()

save(lasso_tune, lasso_tune_plot, best_lasso, lasso_fit,
     lasso_aug, lasso_roc_auc_train, lasso_roc_plot_train,
     file = "lasso_model_results.rda")


#-----------------------------------------------------------------------------#


## Elastic Net

elastic_model <- logistic_reg(penalty = tune(), mixture = tune()) %>%
  set_engine("glmnet") %>%
  set_mode("classification")

elastic_wflow <- workflow() %>%
  add_model(elastic_model) %>%
  add_recipe(scf_recipe)

elastic_grid <- grid_regular(
  penalty(range = c(0, 1), trans = identity_trans()),
  mixture(range = c(0, 1)),
  levels = 10
)

elastic_tune <- tune_grid(
  elastic_wflow,
  resamples = folds,
  grid = elastic_grid,
  metrics = metric_set(roc_auc)
)

elastic_tune_plot <- autoplot(elastic_tune)

best_elastic <- elastic_tune %>%
  select_by_one_std_err(metric = "roc_auc", penalty, mixture)

final_elastic <- finalize_workflow(elastic_wflow, best_elastic)
elastic_fit <- fit(final_elastic, train_data)

elastic_aug <- augment(elastic_fit, new_data = train_data)

elastic_roc_auc_train <- elastic_aug %>%
  roc_auc(truth = occ_group, .pred_white_collar)

elastic_roc_plot_train <- elastic_aug %>%
  roc_curve(truth = occ_group, .pred_white_collar) %>%
  autoplot()

save(elastic_tune, elastic_tune_plot, best_elastic, elastic_fit,
     elastic_aug, elastic_roc_auc_train, elastic_roc_plot_train,
     file = "elastic_net_model_results.rda")



#------------------------------------------------------------------------------#


## Random Forest
rf_model <- rand_forest(
  mtry = tune(),
  trees = tune(),
  min_n = tune()
) %>%
  set_engine("ranger", importance = "impurity") %>%
  set_mode("classification")

rf_wflow <- workflow() %>%
  add_model(rf_model) %>%
  add_recipe(scf_recipe)

rf_grid <- grid_regular(
  mtry(range = c(1, 7)),
  trees(range = c(200, 600)),
  min_n(range = c(10, 20)),
  levels = 5
)

rf_tuned <- tune_grid(
  rf_wflow,
  resamples = folds,
  grid = rf_grid,
  metrics = metric_set(roc_auc)
)

rf_tuning_plot <- autoplot(rf_tuned) + theme_minimal()

show_best(rf_tuned, metric = "roc_auc", n = 1)

rf_best <- select_best(rf_tuned, metric = "roc_auc")

## We carry out testing on the rf model since it is the best

final_rf_model <- finalize_workflow(rf_wflow, rf_best)
rf_fit <- fit(final_rf_model, train_data)
rf_aug <- augment(rf_fit, new_data = train_data)
rf_roc_auc_train <- roc_auc(rf_aug, truth = occ_group, .pred_white_collar)
rf_roc_plot_train <- rf_aug %>%
  roc_curve(truth = occ_group, .pred_white_collar) %>%
  autoplot()

save(rf_tuned, rf_tuning_plot, rf_best, final_rf_model, rf_fit,
     rf_aug, rf_roc_auc_train, rf_roc_plot_train,   rf_wflow,
     file = "random_forest_model.rda")

